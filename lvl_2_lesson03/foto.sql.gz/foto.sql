-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3301
-- Время создания: Апр 29 2020 г., 09:02
-- Версия сервера: 8.0.15
-- Версия PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `foto`
--

-- --------------------------------------------------------

--
-- Структура таблицы `gallery`
--

CREATE TABLE `gallery` (
  `ID` int(11) NOT NULL,
  `URL` varchar(255) NOT NULL,
  `SIZE` char(255) NOT NULL,
  `NAME` char(255) NOT NULL,
  `views` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `gallery`
--

INSERT INTO `gallery` (`ID`, `URL`, `SIZE`, `NAME`, `views`) VALUES
(3, 'img\\small\\05.jpg', '48,4КБ', '05.jpg', 9),
(4, 'img\\small\\09.jpg', '28КБ', '09.jpg', 11),
(7, 'img\\small\\13.jpg', '42KB', '13.jpg', 7),
(8, 'img\\small\\157253454377.jpg', '31KB', '157253454377.jpg', 6),
(11, 'img\\small\\157253604134.jpg', '20KB', '157253604134.jpg', 13),
(12, 'img\\small\\fon.png', '52KB', 'fon.png', 8),
(13, 'img\\full\\05.jpg', '148,4КБ', '05.jpg', 7),
(14, 'img\\full\\09.jpg', '128КБ', '09.jpg', 7),
(15, 'img\\full\\13.jpg', '142KB', '13.jpg', 7),
(16, 'img\\full\\157253454377.jpg', '131KB', '157253454377.jpg', 7),
(17, 'img\\full\\157253604134.jpg', '120KB', '157253604134.jpg', 7),
(18, 'img\\full\\fon.png', '152KB', 'fon.png', 7);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `gallery`
--
ALTER TABLE `gallery`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
